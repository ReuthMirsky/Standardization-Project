/****************************************
 * Yael Margalit
 * Yair Vaknin
 ****************************************/

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/****************************************
 * class Main.
 * gets two command line arguments - 
 * 		1. path to CSQ output file.
 * 		2. path to plan library.
 * the program parse the plan library into a tree of plans,
 * look at CSQ output file and taggs nodes in plan library accordingly.
 * relevant data is put on a hash map, and HSQ algorithm is applied on it.
 * then output graph in xml format is generated. 
 ****************************************/
public class Main {

	public static void main(String[] args) throws FileNotFoundException {
		
		File f = new File(args[0]);
		@SuppressWarnings("resource")
		BufferedReader br = new BufferedReader(new FileReader(f)); 
		
		// parse plan library and takes all plans in it to a list
		Parser parser = new Parser();
		Plan root = parser.parse(args[1]);
		List<Plan> plans = root.search();
		
		// extract data from CSQ output file, and represent it on according plans from the list.
		try {	
			String line;
			while ((line = br.readLine()) != null) {
				int ws = line.indexOf(' ');
				int t = Integer.parseInt(line.substring(0, ws));
				String label = line.substring(ws + 1, line.length());
				Plan p = null;
				for (Plan tmp: plans) {			
					if (tmp.getLabel().equals(label)) {
						p = tmp; 					
						break;						
					}								
				}
				p.tag(t, "Hard");
			}
		} catch (Exception e) {
			System.out.println("error reading from file");
		}
		
		// put relevant data on a hash map.
		HashMap<Integer, List<Plan>> map = new HashMap<Integer, List<Plan>>();
		for (Plan n: root.search()) {
			for (int t: n.getTags()) {
				if (n.getChildren().isEmpty()) {
					if (map.containsKey(t)) {
						map.get(t).add(n);
					}
					else {
						List<Plan> lst = new ArrayList<Plan>();
						lst.add(n);
						map.put(t, lst);
					}
				}
			}
		}
		
		// assign HSQ algorithm with a random int.
		// (can also be a boolean flag, 
		// I picked an int for it supports serial activations of the algorithm)
		int serial = 7;
		HSQ h = new HSQ();
		Plan XMLroot = h.hsq(map, serial);
		
		// write xml file.
		ParserCreateXml writeXml = new ParserCreateXml();
		writeXml.writeXmlFile(XMLroot);
	}
}
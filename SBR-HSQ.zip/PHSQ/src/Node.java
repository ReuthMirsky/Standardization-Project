/****************************************
 * Yael Margalit
 * Yair Vaknin
 ****************************************/

/****************************************
 * class Node.
 * base class of Plan class.
 * all members and methods that are common to a Plan and a regular graph node
 * should be here (that's not done).
 ****************************************/
abstract class Node {

	protected boolean isRoot;
	
	public boolean root() {
		return isRoot;
	}
}

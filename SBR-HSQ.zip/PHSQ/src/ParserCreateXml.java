import java.util.List;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import java.io.File;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Attr;

/****************************************
 * Yael Margalit Yair Vaknin
 ****************************************/

public class ParserCreateXml {

	/**
	 * 
	 * class ParserCreateXML write hsq output to xml file
	 *
	 */

	/****************************************
	 * method: writeXmlFile input: HashMap<Integer, List<Plan>> plans - hash map
	 * of time_stamps and matching plans. output: void. operation: iterate over
	 * plans in hash map, and write it to xml file
	 ****************************************/
	public void writeXmlFile(Plan root) {
		try {
			DocumentBuilderFactory docFactory = DocumentBuilderFactory
					.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();

			Document doc = docBuilder.newDocument();

			Element MainrootElement = doc.createElement("hypotheses");
			doc.appendChild(MainrootElement);

			// set the hypotheses counter to 1
			Integer hypothesisCounter = new Integer(1);

			List<List<Plan>> hypoteses = root.getHypoteses();
			/**
			 * go over all hypotheses
			 */
			for (List<Plan> hypothesis : hypoteses) {
				Element rootElement = doc.createElement("hypothesis_"
						.concat(hypothesisCounter.toString()));
				MainrootElement.appendChild(rootElement);

				// set the nodes paths counter to 1
				Integer nodesPathsCounter = new Integer(1);

				/**
				 * go over all nodes in hypothesis.
				 */
				for (Plan p : hypothesis) {
					if (!p.getTags().isEmpty()) {

						// create node_path elements
						Element nodePath = doc.createElement("node_path_"
								.concat(nodesPathsCounter.toString()));
						rootElement.appendChild(nodePath);

						/**
						 * set attribute label to node_path element, and insert
						 * node label.
						 */
						Attr attrLabel = doc.createAttribute("label");
						attrLabel.setValue(p.getLabel());
						nodePath.setAttributeNode(attrLabel);

						// set attribute param1 to node_path element
						Attr attrParam1 = doc.createAttribute("param1");
						attrParam1.setValue("value1");
						nodePath.setAttributeNode(attrParam1);

						// set attribute param2 to node_path element
						Attr attrParam2 = doc.createAttribute("param2");
						attrParam2.setValue("value2");
						nodePath.setAttributeNode(attrParam2);

						/**
						 * set attribute time to node_path element, and insert
						 * node time stamp.
						 */
						Attr attrTime = doc.createAttribute("time");
						attrTime.setValue(p.getTags().get(0).toString());
						nodePath.setAttributeNode(attrTime);

						/**
						 * go over all nodes on path nodes
						 */
						if (!p.getPath().isEmpty()) {
							for (String entry : p.getPath()) {

								// create basic_node elements
								Element basicNode = doc
										.createElement("basic_node");
								nodePath.appendChild(basicNode);

								/**
								 * set attribute label to node_path element, and
								 * insert node label.
								 */
								Attr attrLabelBN = doc.createAttribute("label");
								attrLabelBN.setValue(entry);
								basicNode.setAttributeNode(attrLabelBN);

								// set attribute param1 to basic_node element
								Attr attrParam1BN = doc
										.createAttribute("param1");
								attrParam1BN.setValue("value1");
								basicNode.setAttributeNode(attrParam1BN);

								// set attribute param2 to basic_node element
								Attr attrParam2BN = doc
										.createAttribute("param2");
								attrParam2BN.setValue("value2");
								basicNode.setAttributeNode(attrParam2BN);

								/**
								 * set attribute time to basic_node element, and
								 * insert node time stamp.
								 */
								Attr attrTimeBN = doc.createAttribute("time");
								attrTimeBN.setValue(p.getTags().get(0)
										.toString());
								basicNode.setAttributeNode(attrTimeBN);
							}

							// update nodes paths counter
							nodesPathsCounter++;
						}
					}
				}
				// update hypothesis counter
				hypothesisCounter++;
			}

			// write the content into xml file
			TransformerFactory transformerFactory = TransformerFactory
					.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			DOMSource source = new DOMSource(doc);
			StreamResult result = new StreamResult(new File("HSQoutput.xml"));

			// Output to console for testing
			// StreamResult result = new StreamResult(System.out);

			transformer.transform(source, result);

		} catch (ParserConfigurationException pce) {
			pce.printStackTrace();
		} catch (TransformerException tfe) {
			tfe.printStackTrace();
		}
	}
}
/****************************************
 * Yael Margalit
 * Yair Vaknin
 ****************************************/

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/****************************************
 * class HSQ.
 * HSQ algorithm.
*****************************************/
public class HSQ {

	/****************************************
	 * method: hsq
	 * input:
	 * 		HashMap<Integer, List<Plan>> plans - hash map of time_stamps and matching plans.
	 * 		int serial - used to mark plans. can be replaced with a boolean flag.
	 * output:
	 * 		Plan root.
	 * operation: removes plans from original hash map, organises the remaining plans as a tree.
	 ****************************************/
	public Plan hsq(HashMap<Integer, List<Plan>> plans, int serial) {
		
		List<Plan> tmp = new ArrayList<Plan>();
		
		Plan root = new Plan("root");
		root.setSerial(serial);
		tmp.add(root);
		plans.put(plans.size() + 1, tmp);
		
		for (int i = plans.size(); i > 1; i--) {
			List<Plan> rmv = new ArrayList<Plan>();
			for (Plan n1: plans.get(i)) {
				
				// if a plan is relevant, work on it -
				if (n1.getSerial() == serial) {
					for (Plan n2: plans.get(i - 1)) {
						// if a plan could be the child of another -
						if (Plan.hasChild(n1.getSeqOf(),n2) ||
								n1.getLabel().equals("root")||
								n1.getSeqOf().isEmpty()) {
							// mark and add an according plan to tree.
							n2.setSerial(serial);			
							Plan p = new Plan(n2);
							root.findByLabel(n1.getLabel()).addChild(p);
						}
					}	
				}		
				// otherwise, add it to remove list.
				else {
					rmv.add(n1);
				}
			}
			// delete plans in remove list.
			for (Plan plan: rmv) {
				plans.get(i).remove(plan);
			}
		}
		
		plans.remove(plans.size());
		return root;
	}
}

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.File;
import java.util.*;

/**
 * Created by noa on 11-Dec-16.
 */
public class XmlParser {
    Set<String> terminals; //for further use;
    //save all ids for each action
    HashMap <String,ArrayList<String>> nameToIdDict;

    public XmlParser()
    {
        terminals = new HashSet<>();
        nameToIdDict = new HashMap<>();
    }

    //Parse the given xmlFile
    public void Parse(String xmlFilePath)
    {
        try {
            File inputFile = new File(xmlFilePath);
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(inputFile);
            doc.getDocumentElement().normalize();

            //check if the line's tag is Letter
            NodeList nList = doc.getElementsByTagName("Letter");
            String prevName = "";
            //get all lines with the "Letter" tag
            for (int temp = 0; temp < nList.getLength(); temp++) {
                Node nNode = nList.item(temp);
                if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element eElement = (Element) nNode;
                    //get the tag of the parent element
                    String parent = eElement.getParentNode().getNodeName();
                    if (parent == "Terminals" || parent == "Non-Terminals") {
                        //get the element's name
                        String currName = eElement.getAttribute("name");
                        //if there is no entry in the HashMap for the name add a new Array List to the HashMap
                        if (!prevName.equals(currName)){
                            terminals.add(currName);
                            nameToIdDict.put(currName,new ArrayList<>());
                            prevName = currName;
                        }
                        //add the element's id to the HashMap
                        String id = eElement.getAttribute("id");
                        nameToIdDict.get(currName).add(id);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


}


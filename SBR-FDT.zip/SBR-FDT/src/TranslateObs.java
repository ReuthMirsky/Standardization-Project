import java.io.*;

/**
 * Created by noa on 11-Dec-16.
 * This class translates an observations' file to an outpt file with FDT format
 */
public class TranslateObs {

    //translate an observations' file to an output file according to xmlFile
    public void translate(String xmlFilePath,String obsFilePath, String OutputFilePath) throws IOException {
        try (FileReader fr = new FileReader(obsFilePath)) {
            //crete parser instance
            XmlParser xmlParser = new XmlParser();
            xmlParser.Parse(xmlFilePath);
            BufferedReader br = new BufferedReader(fr);
            String sCurrentLine;
            PrintWriter writer = new PrintWriter(OutputFilePath, "UTF-8");
            int actId = 0;
            //read the observations file
            while ((sCurrentLine =br.readLine()) != null) {
                actId++;
                //write each id of the act's name to the output file ing FDT format
                for (String id: xmlParser.nameToIdDict.get(sCurrentLine)) {
                    writer.write("" + actId + " " + id+"\n");
                }
            }
            writer.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

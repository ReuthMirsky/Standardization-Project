import java.io.IOException;

public class Main {

    public static void main(String[] args) {
        TranslateObs tr = new TranslateObs();
        try {
            tr.translate("planlibrary_soccer-full.xml","observations_soccer2.txt","FDToutput.txt");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}




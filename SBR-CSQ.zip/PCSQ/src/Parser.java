/****************************************
 * Yael Margalit
 * Yair Vaknin
 ****************************************/

import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

public class Parser {

	public Plan parse(String path) throws FileNotFoundException {
		Plan root = new Plan("root");
		boolean isRoot = true;
		HashMap<String, Plan> hmap = new HashMap<String, Plan>();

		   try
	        {
	            File fXmlFile = new File(path);//"book.xml");
	             DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
	             DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
	             Document doc = dBuilder.parse(fXmlFile);
	             doc.getDocumentElement().normalize();
	             
	             NodeList Recipes = doc.getElementsByTagName("Recipe");
	             
	             for(int i=0;i < Recipes.getLength();i++) {
	                 Element Recipe = (Element) Recipes.item(i);
	                 Plan p = new Plan(Recipe.getAttribute("lhs"));
	                 
	              // if it's the first node, set it's to root
						if (isRoot) {
							root = p;
							isRoot = false;
						}

						// else find the node in tree or create a new node if
						// doesn't exist
						else {
							p = root.findByLabel(Recipe.getAttribute("lhs"));
							if (p == null) {
								p = new Plan(Recipe.getAttribute("lhs"));
							}
						}
	                 
	                 //parse the Letters - children's of recipe.
	                 int j=0;
	                 Element Letter = (Element) Recipe.getElementsByTagName("Letter").item(j);
	                 
	                 while(Letter != null) {
	                	 //add plan children's 
	                	 Plan child = new Plan(p, Letter.getAttribute("id"));
	                	 
	                	 hmap.put(Letter.getAttribute("index"), child);
	                	 
	                	 //parse next letter
	                	 j += 1;
	                	 Letter = (Element) Recipe.getElementsByTagName("Letter").item(j); 
	                 }
	                 
	               //parse the OrderCons - seq edges.
	                 int k=0;
	                 Element OrderCons = (Element) Recipe.getElementsByTagName("OrderCons").item(k);
	                 
	                 while(OrderCons != null) {
	                	 //add seq edges
	                	 hmap.get(OrderCons.getAttribute("firstIndex")).addSeq(hmap.get(OrderCons.getAttribute("secondIndex")));
	                	 
	                	 k += 1;
		                 OrderCons = (Element) Recipe.getElementsByTagName("OrderCons").item(k);
	                 }
	                 
	                 
	             }
	             
	        }
	        catch (Exception ex)
	        {
	        	System.out.println("error reading from file");
	            ex.printStackTrace();
	        }
		
		return root;
	}
}
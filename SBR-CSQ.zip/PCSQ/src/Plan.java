/****************************************
 * Yael Margalit
 * Yair Vaknin
 ****************************************/

import java.util.ArrayList;
import java.util.List;

/****************************************
 * class Plan, derived from Node.
 * represents a plan in plan library, and has the needed members and methods.
 ****************************************/
public class Plan extends Node {

	private Plan parent;
	private String label;
	
	private int serial = -1;
	
	private int memory = -1;
	private int minDuration = 0;
	private int maxDuration = 9;
	private int maximumInterruptTime = 1;
	
	private List<Plan> children = new ArrayList<Plan>();
	private List<Plan> seqs = new ArrayList<Plan>();
	private List<Plan> seqof = new ArrayList<Plan>();
	
	private List<String> path = new ArrayList<String>();
	
	private List<Integer> hardTags = new ArrayList<Integer>();
	private List<Integer> softTags = new ArrayList<Integer>();
	
	/****************************************
	 * method: Plan
	 * input:
	 * 		String s - label.
	 * output:
	 * operation: constructor.
	 ****************************************/
	public Plan(String s) {
		parent = null;
		label = s;
		isRoot = true;
		path.add(s);
	}

	/****************************************
	 * method: Plan
	 * input:
	 * 		Plan parent.
	 * 		String label - plan's label.
	 * output:
	 * operation: constructor.
	 ****************************************/
	public Plan(Plan parent, String label) {
		this.parent = parent;
		this.label = label;
		parent.addChild(this);
		isRoot = false;
		for (String s: this.parent().getPath()) {
			path.add(s);
		}
		path.add(label);
	}
	
	/****************************************
	 * method: Plan
	 * input:
	 * 		Plan other.
	 * output:
	 * operation: constructor.
	 ****************************************/
	public Plan(Plan other) {
		label = other.getLabel();
		isRoot = false;
		hardTags = other.getTags();
		path = other.getPath();		
	}
	
	/****************************************
	 * method: getPath
	 * input:
	 * output: 
	 * 		List<String> path.
	 * operation: getter.
	 ****************************************/
	public List<String> getPath() {
		return path;
	}
	
	/****************************************
	 * method: minDuration
	 * input:
	 * output: 
	 * 		int minDuration.
	 * operation: getter.
	 ****************************************/
	public int minDuration() {
		return minDuration;
	}
	
	/****************************************
	 * method: maxDuration
	 * input:
	 * output: 
	 * 		int maxDuration.
	 * operation: getter.
	 ****************************************/
	public int maxDuration() {
		return maxDuration;
	}
	
	/****************************************
	 * method: getSerial
	 * input:
	 * output: 
	 * 		int serial number.
	 * operation: getter.
	 ****************************************/
	public int getSerial() {
		return serial;
	}
	
	/****************************************
	 * method: setSerial
	 * input:
	 * 		int i - serial number.
	 * output: 
	 * operation: setter.
	 ****************************************/
	public void setSerial(int i) {
		serial = i;
	}
	
	/****************************************
	 * method: root
	 * input:
	 * output:
	 * 		boolean isroot. 
	 * operation: return True if this is root, false otherwise.
	 ****************************************/
	public boolean root() {
		return isRoot;
	}
		
	/****************************************
	 * method: tag
	 * input:
	 * 		int n - time_stamp.
	 * 		String s - 'soft' or 'hard', depends on kind of tag.
	 * output: 
	 * operation: checks string, and assign tag accordingly.
	 ****************************************/
	public void tag(int n, String s) {
		if (s.equals("Soft")) {
			softTags.add(n);
		}
		if (s.equals("Hard")) {
			hardTags.add(n);
			softTags.add(n);
		}
		memory = n;
	}
	
	/****************************************
	 * method: getSeqOf
	 * input:
	 * output: 
	 * 		List<Plan> of sequential edges.
	 * operation: getter.
	 ****************************************/
	public List<Plan> getSeqOf() {
		List<Plan> l = new ArrayList<Plan>();
		l.addAll(seqof);
		if (parent != null) {
			l.addAll(parent.getSeqOf());
		}
		return l;
	}
	
	/****************************************
	 * method: hasChild
	 * input:
	 * 		List<Plan> plans.
	 * 		Plan plan.
	 * output: 
	 * 		boolean value - True if a given plan is a descendant to a plan in given list,
	 * 						False otherwise.
	 * operation: setter.
	 ****************************************/
	public static Boolean hasChild(List<Plan> plans, Plan plan) {
		for (Plan p: plans) {
			for (Plan p1: p.search()) {
				if (p1 == plan) {
					return true;
				}
			}
		}
		return false;
	}
	
	/****************************************
	 * method: getTags
	 * input:
	 * output: 
	 * 		List<Integer> hardTags.
	 * operation: getter.
	 ****************************************/
	public List<Integer> getTags() {
		return hardTags;
	}
	
	/****************************************
	 * method: getSeqs
	 * input:
	 * output: 
	 * 		List<Plan> of sequential edges.
	 * operation: getter.
	 ****************************************/
	public List<Plan> getSeqs() {
		return seqs;
	}
	
	/****************************************
	 * method: delete_tag
	 * input:
	 * 		Integer n - time_stamp to remove from tags.
	 * output: 
	 * operation: removes according tag.
	 ****************************************/
	public void delete_tag(Integer n) {
		hardTags.remove(n);
		softTags.remove(n);
	}
	
	/****************************************
	 * method: tagged
	 * input:
	 * 		Integer n - time_stamp.
	 * 		String s - 'soft' or 'hard'.
	 * output: 
	 * 		boolean value - True if this is tagged, False accordingly.
	 * operation: checks given String, then checks according list to find a match to time_stamp.
	 ****************************************/
	public boolean tagged(Integer n, String s) {
		if (s.equals("Soft")) {
			return softTags.contains(n);
		}
		if (s.equals("Hard")) {
			return hardTags.contains(n);
		}
		return false;
	}
	
	/****************************************
	 * method: ChildTagged
	 * input:
	 * 		int t - time_stamp.
	 * output: 
	 * 		boolean value - True if this has a child with a given time_stamp, False otherwise.
	 * operation: Iterates over list of children, and checks for a match.
	 ****************************************/
	public boolean ChildTagged(int t) {
		for (Plan d: children) {
			if (d.tagged(t, "Hard")) {
				return true;
			}
		}
		if (children.isEmpty()) {
			return true;
		}
		return false;
	}
	
	/****************************************
	 * method: parent
	 * input:
	 * output: 
	 * 		Plan parent.
	 * operation: return this's parent.
	 ****************************************/
	public Plan parent() {
		return parent;
	}
	
	/****************************************
	 * method: NoSeqEdges
	 * input:
	 * output: 
	 * 		boolean value - True if no sequential edges exist, False otherwise.
	 * operation: checks if there are sequential edges.
	 ****************************************/
	public boolean NoSeqEdges() {
		return seqof.isEmpty();
	}
	
	/****************************************
	 * method: PreviousSeqEdgeTaggedWithHard
	 * input:
	 * 		int t.
	 * output: 
	 * 		boolean value - True if there is a sequential edge of a certain range, False otherwise.
	 * operation: iterates over sequential edges and looks for a match.
	 ****************************************/
	public boolean PreviousSeqEdgeTaggedWithHard(int t) {
		for (int i = 0; i <= maximumInterruptTime; i++) {
			for (Plan n: seqof) {
				if (n.getMemory() != -1 && n.getMemory() >= t - i) {
					return true;
				}
			}
		}
		return false;
	}
	
	/****************************************
	 * method: getMemory
	 * input:
	 * output: 
	 * 		int memory.
	 * operation: getter.
	 ****************************************/
	private int getMemory() {
		return memory;
	}
	
	/****************************************
	 * method: search
	 * input:
	 * output: 
	 * 		List<Plan> - all descendant of a plan.
	 * operation: recursive calls to all children.
	 ****************************************/
	public List<Plan> search() {
		List<Plan> lst = new ArrayList<Plan>();
		lst.add(this);
		for (Plan n: children) {
			lst.addAll(n.search());
		}
		return lst;
	}
	
	/****************************************
	 * method: getChildren
	 * input:
	 * output: 
	 * 		List<Plan> children.
	 * operation: getter.
	 ****************************************/
	public List<Plan> getChildren() {
		return children;
	}
	
	/****************************************
	 * method: addChild
	 * input:
	 * 		Plan child.
	 * output: 
	 * operation: add a plan to list of children.
	 ****************************************/
	public void addChild(Plan child) {
		children.add(child);
		child.setParent(this);
	}
	
	/****************************************
	 * method: addSeq
	 * input:
	 * 		Plan seq.
	 * output: 
	 * operation: add a plan to list of sequential edges, add this to seq's sequential edges.
	 ****************************************/
	public void addSeq(Plan seq) {
		seqs.add(seq);
		seq.addToSeqOf(this);
	}
	
	/****************************************
	 * method: addToSeqOf
	 * input:
	 * 		Plan n.
	 * output: 
	 * operation: add a plan to list of sequential edges.
	 ****************************************/
	public void addToSeqOf(Plan n) {
		seqof.add(n);
	}
	
	/****************************************
	 * method: getLabel
	 * input:
	 * output: 
	 * 		String label.
	 * operation: getter.
	 ****************************************/
	public String getLabel() {
		return label;
	}
	
	/****************************************
	 * method: findByLabel
	 * input:
	 * 		String s.
	 * output:
	 * 		Plan - a plan that matches a given String.
	 * operation: checks for accordance between a given string and this's label,
	 * 			  and if not found - done recursively on this's children.
	 ****************************************/
	public Plan findByLabel(String s) {
		if (s.equals(label)) {
			return this;
		}
		for (Plan p: this.search()) {
			if (p.getLabel().equals(s)) {
				return p;
			}
		}
		return null;
	}

	/****************************************
	 * method: getLeaves
	 * input:
	 * output:
	 * 		List<Plan> of all leaves
	 * operation: uses search(), and remove from it all nodes that have children.
	 ****************************************/
	private List<Plan> getLeaves() {
		List<Plan> leaves = new ArrayList<Plan>();
		for (Plan p: this.search()) {
			if (p.getChildren().isEmpty()) {
				leaves.add(p);
			}
		}
		return leaves;
	}
	
	/****************************************
	 * method: getHypoteses
	 * input:
	 * output:
	 * 		List<List<Plan>> of all hypoteses.
	 * operation: uses getLeaves(), follow each Plan in it up to the root to tell the entire hypotesis.
	 ****************************************/
	public List<List<Plan>> getHypoteses() {
		List<List<Plan>> hypoteses = new ArrayList<List<Plan>>();
		List<Plan> leaves = this.getLeaves();
		for (Plan p: leaves) {
			List<Plan> hypotesis = new ArrayList<Plan>();
			while (p != null) {
				hypotesis.add(new Plan(p));
				p = p.parent();
			}
			hypoteses.add(hypotesis);
		}
		return hypoteses;
	}
	
	/****************************************
	 * method: setParent
	 * input:
	 * 		Plan parent.
	 * output:
	 * operation: setter.
	 ****************************************/
	public void setParent(Plan parent) {
		this.parent = parent;
	}
}

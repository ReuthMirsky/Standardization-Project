/****************************************
 * Yael Margalit
 * Yair Vaknin
 ****************************************/

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.List;

/****************************************
 * class Main.
 * gets two command line arguments - 
 * 		1. path to FDT output file.
 * 		2. path to plan library.
 * the program parse the plan library into a tree of plans,
 * and then CSQ algorithm is applied on each plan found in FDT output file and the plan library.
 * the program outputs "time_stamp plan" format file.  
 ****************************************/
public class Main {

	public static void main(String[] args) throws FileNotFoundException {

		// parse plan library
		Parser parser = new Parser();
		Plan root = parser.parse(args[1]);
		
		File f = new File(args[0]);
		@SuppressWarnings("resource")
		BufferedReader br = new BufferedReader(new FileReader(f)); 
		
		CSQ csq = new CSQ();
		List<Plan> plans = root.search();
		
		// extract each time_stamp and plan
		try {	
			String line;
			while ((line = br.readLine()) != null) {
				int ws = line.indexOf(' ');
				int t = Integer.parseInt(line.substring(0, ws));
				String label = line.substring(ws + 1, line.length());
				Plan p = null;
				for (Plan tmp: plans) {
					if (tmp.getLabel().equals(label)) {	
						p = tmp;
						break;						
					}								
				}
				// and apply CSQ algorithm
				csq.csq(p, root, t);
			}
		} catch (Exception e) {
			System.out.println("error reading from file");
		}
		
		// create output file
		PrintWriter writer = null;
        try {
            writer = new PrintWriter("CSQoutput.txt", "UTF-8");
        } catch (FileNotFoundException e) {      
            e.printStackTrace();
        } catch (UnsupportedEncodingException e) { 
            e.printStackTrace();
        }
		
        // write to file, and close
		for (Plan n: root.search()) {
			for (int t: n.getTags()) {
				writer.append(t + " " + n.getLabel() + "\n");
			}
		}
		writer.close();
	}
}

/****************************************
 * Yael Margalit
 * Yair Vaknin
 ****************************************/

import java.util.ArrayList;
import java.util.List;

/****************************************
 * class CSQ.
 * CSQ algorithm and necessary methods.
*****************************************/
public class CSQ {

	/****************************************
	 * method: csq
	 * input:
	 * 		Plan M.
	 * 		Plan g.
	 * 		int t - time_stamp.
	 * output:
	 * operation: assign t on according plan, propagates it up, and removes irrelevant tags.
	 ****************************************/
	public void csq(Plan M, Plan g, int t) {
		propagateUp(M, g, t);
		while (M.tagged(t, "Hard") && !M.ChildTagged(t)) { 
			M.delete_tag(t);
			M = M.parent();
		}
	}
	
	/****************************************
	 * method: propagateUp
	 * input:
	 * 		Plan w.
	 * 		Plan pl - plan library.
	 * 		int t - time_stamp.
	 * output:
	 * operation: assign t on plan w from pl, 
	 * 			  and propagates up the tag until root is reached.
	 ****************************************/
	private void propagateUp(Plan w, Plan pl, int t) {
		
		List<Plan> Tagged = new ArrayList<Plan>();
		boolean propagateUpSuccess = true;
		Plan v = w;
		
		while (!v.root() && propagateUpSuccess && !v.tagged(t, "Hard")) {
			if (calcDuration(v, t) < v.maxDuration()) {
				if (isConsistent(v, pl, t)) {
					if (calcDuration(v, t) < v.minDuration()) {
						v.tag(t, "Soft");
					}
					else {
						v.tag(t, "Hard");
					}
					Tagged.add(v);
					v = v.parent();
					propagateUpSuccess = true;
				}
				else {
					propagateUpSuccess = false;
				}
			}
			else {
				propagateUpSuccess = false;
			}
		}

		if (!propagateUpSuccess) {
			for (Plan a: Tagged) {
				a.delete_tag(t);
			}
		}
	}

	/****************************************
	 * method: calcDuration
	 * input:
	 * 		Plan v.
	 * 		int t - time_stamp.
	 * output:
	 * 		int counter - the duration in whice the plan was active.
	 * operation:
	 ****************************************/
	private int calcDuration(Plan v, int t) {
		int counter = 0;
		int time = t;
		while (time > 0) {
			if (v.tagged(t - 1, "Soft")) {
				counter++;
				time--;
			}
			else {
				break;
			}
		}
		return counter;
	}
	
	/****************************************
	 * method: isConsistent
	 * input:
	 * 		Plan v.
	 * 		Plan g.
	 * 		int t - time_stamp.
	 * output:
	 * 		boolean value - True if plan is consistent with time_stamp, False otherwise.
	 * operation:
	 ****************************************/
	private boolean isConsistent(Plan v, Plan g, int t) {
		if (v.parent().tagged(t, "Soft") || true /* in assay - "|| features(parent(v) != o", I swapped that with 'True' */) {
			if (v.tagged(t - 1, "Soft") || v.PreviousSeqEdgeTaggedWithHard(t - 1) || v.NoSeqEdges()) {
				return true;
			}
		}
		return false;
	}
}
